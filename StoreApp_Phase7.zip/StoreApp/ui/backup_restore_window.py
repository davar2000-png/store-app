# -*- coding: utf-8 -*-
"""پنجره «پشتیبان‌گیری و بازیابی کامل دیتابیس»"""

from PyQt6.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QTableWidget, QTableWidgetItem,
    QPushButton, QLineEdit, QLabel, QTabWidget, QHeaderView,
    QMessageBox, QFileDialog, QCheckBox, QGroupBox, QFormLayout
)
from PyQt6.QtCore import Qt
import sys, os

sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
import services.backup_service as bkp


def make_table(headers):
    table = QTableWidget()
    table.setColumnCount(len(headers))
    table.setHorizontalHeaderLabels(headers)
    table.horizontalHeader().setSectionResizeMode(0, QHeaderView.ResizeMode.Stretch)
    table.setEditTriggers(QTableWidget.EditTrigger.NoEditTriggers)
    return table


class BackupTab(QWidget):
    def __init__(self, current_user):
        super().__init__()
        self.current_user = current_user
        self._build_ui()
        self.load_folder()
        self.refresh_history()

    def _build_ui(self):
        layout = QVBoxLayout()

        folder_box = QGroupBox("مسیر پوشه پشتیبان")
        folder_form = QFormLayout()
        row = QHBoxLayout()
        self.folder_input = QLineEdit()
        browse_btn = QPushButton("📂 انتخاب پوشه...")
        browse_btn.clicked.connect(self.browse_folder)
        save_btn = QPushButton("💾 ذخیره مسیر")
        save_btn.clicked.connect(self.save_folder)
        row.addWidget(self.folder_input)
        row.addWidget(browse_btn)
        row.addWidget(save_btn)
        folder_form.addRow("مسیر:", row)
        note = QLabel(
            "⚠️ این مسیر باید توسط «سرویس SQL Server» قابل‌نوشتن باشد، نه فقط توسط "
            "کاربر ویندوز شما. بهتر است یک پوشه ساده روی همان کامپیوتر SQL Server باشد."
        )
        note.setWordWrap(True)
        note.setStyleSheet("color: #7a5c00;")
        folder_form.addRow(note)
        folder_box.setLayout(folder_form)
        layout.addWidget(folder_box)

        backup_btn = QPushButton("📥 تهیه نسخه پشتیبان الان")
        backup_btn.setStyleSheet("font-weight: bold; padding: 8px;")
        backup_btn.clicked.connect(self.do_backup)
        layout.addWidget(backup_btn)

        layout.addWidget(QLabel("فایل‌های پشتیبان موجود در این پوشه:"))
        self.files_table = make_table(["نام فایل", "حجم (MB)", "تاریخ ساخت"])
        layout.addWidget(self.files_table)

        layout.addWidget(QLabel("تاریخچه پشتیبان‌گیری:"))
        self.history_table = make_table(["نوع عملیات", "تاریخ", "مسیر فایل", "حجم (MB)", "وضعیت", "خطا"])
        layout.addWidget(self.history_table)

        self.setLayout(layout)

    def load_folder(self):
        self.folder_input.setText(bkp.get_backup_folder())
        self.refresh_files()

    def browse_folder(self):
        path = QFileDialog.getExistingDirectory(self, "انتخاب پوشه پشتیبان")
        if path:
            self.folder_input.setText(path)

    def save_folder(self):
        bkp.set_backup_folder(self.folder_input.text().strip())
        QMessageBox.information(self, "ذخیره شد", "مسیر پوشه پشتیبان ذخیره شد.")
        self.refresh_files()

    def do_backup(self):
        folder = self.folder_input.text().strip()
        if not folder:
            QMessageBox.warning(self, "توجه", "ابتدا مسیر پوشه پشتیبان را وارد کنید.")
            return
        try:
            path = bkp.backup_database(folder, self.current_user["ID"])
            QMessageBox.information(self, "موفق", f"نسخه پشتیبان با موفقیت ساخته شد:\n{path}")
        except bkp.BackupError as e:
            QMessageBox.critical(self, "خطا", str(e))
        self.refresh_files()
        self.refresh_history()

    def refresh_files(self):
        files = bkp.list_backup_files(self.folder_input.text().strip())
        self.files_table.setRowCount(len(files))
        for r, f in enumerate(files):
            self.files_table.setItem(r, 0, QTableWidgetItem(f["name"]))
            self.files_table.setItem(r, 1, QTableWidgetItem(str(f["size_mb"]) if f["size_mb"] is not None else ""))
            self.files_table.setItem(r, 2, QTableWidgetItem(str(f["modified"]) if f["modified"] else ""))

    def refresh_history(self):
        rows = bkp.get_backup_history()
        rows = [r for r in rows if r["ActionType"] == "Backup"]
        self.history_table.setRowCount(len(rows))
        for r, row in enumerate(rows):
            values = [
                row["ActionType"], row["ShamsiDate"] or "", row["FilePath"] or "",
                str(row["FileSizeMB"]) if row["FileSizeMB"] is not None else "",
                row["Status"], row["ErrorMessage"] or ""
            ]
            for c, v in enumerate(values):
                self.history_table.setItem(r, c, QTableWidgetItem(v))


class RestoreTab(QWidget):
    def __init__(self, current_user):
        super().__init__()
        self.current_user = current_user
        self.selected_file = None
        self._build_ui()
        self.refresh_history()

    def _build_ui(self):
        layout = QVBoxLayout()

        warn = QLabel(
            "⚠️ هشدار مهم: با بازیابی، تمام اطلاعات فعلی دیتابیس با اطلاعات داخل فایل "
            "پشتیبان جایگزین می‌شود و این کار غیرقابل بازگشت است.\n"
            "قبل از ادامه: (۱) از همه پنجره‌های باز برنامه خارج شوید و آن را کاملاً ببندید، "
            "(۲) مطمئن شوید هیچ کاربر دیگری روی سیستم‌های دیگر به برنامه وصل نیست، "
            "(۳) در صورت شک، یک پشتیبان تازه از وضعیت فعلی هم بگیرید."
        )
        warn.setWordWrap(True)
        warn.setStyleSheet("color: #b30000; font-weight: bold; background-color: #ffe8e8; padding: 10px; border-radius: 4px;")
        layout.addWidget(warn)

        file_row = QHBoxLayout()
        self.file_label = QLabel("(فایلی انتخاب نشده)")
        browse_btn = QPushButton("📂 انتخاب فایل .bak")
        browse_btn.clicked.connect(self.browse_file)
        file_row.addWidget(self.file_label)
        file_row.addWidget(browse_btn)
        layout.addLayout(file_row)

        self.confirm_check = QCheckBox("می‌دانم این عملیات تمام اطلاعات فعلی را جایگزین می‌کند و غیرقابل بازگشت است.")
        layout.addWidget(self.confirm_check)

        restore_btn = QPushButton("♻️ بازیابی از این فایل")
        restore_btn.setStyleSheet("font-weight: bold; padding: 8px; color: #b30000;")
        restore_btn.clicked.connect(self.do_restore)
        layout.addWidget(restore_btn)

        layout.addWidget(QLabel("تاریخچه بازیابی‌های قبلی:"))
        self.history_table = make_table(["نوع عملیات", "تاریخ", "مسیر فایل", "وضعیت", "خطا"])
        layout.addWidget(self.history_table)

        self.setLayout(layout)

    def browse_file(self):
        start_dir = bkp.get_backup_folder()
        start_dir = start_dir if os.path.isdir(start_dir) else ""
        path, _ = QFileDialog.getOpenFileName(self, "انتخاب فایل پشتیبان", start_dir, "SQL Backup (*.bak)")
        if path:
            self.selected_file = path
            self.file_label.setText(path)

    def do_restore(self):
        if not self.selected_file:
            QMessageBox.warning(self, "توجه", "ابتدا یک فایل .bak انتخاب کنید.")
            return
        if not self.confirm_check.isChecked():
            QMessageBox.warning(self, "توجه", "لطفاً ابتدا تیک تأیید خطرناک‌بودن عملیات را بزنید.")
            return

        confirm = QMessageBox.question(
            self, "تأیید نهایی بازیابی",
            "آیا کاملاً مطمئن هستید؟ تمام اطلاعات فعلی دیتابیس پاک و با فایل پشتیبان "
            "جایگزین می‌شود. این کار قابل بازگشت نیست.",
            QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No,
            QMessageBox.StandardButton.No
        )
        if confirm != QMessageBox.StandardButton.Yes:
            return

        try:
            bkp.restore_database(self.selected_file, self.current_user["ID"])
            QMessageBox.information(
                self, "موفق",
                "بازیابی با موفقیت انجام شد.\nبرای اطمینان کامل، لطفاً برنامه را ببندید و دوباره باز کنید."
            )
        except bkp.BackupError as e:
            QMessageBox.critical(self, "خطا", str(e))
        self.refresh_history()

    def refresh_history(self):
        rows = bkp.get_backup_history()
        rows = [r for r in rows if r["ActionType"] == "Restore"]
        self.history_table.setRowCount(len(rows))
        for r, row in enumerate(rows):
            values = [
                row["ActionType"], row["ShamsiDate"] or "", row["FilePath"] or "",
                row["Status"], row["ErrorMessage"] or ""
            ]
            for c, v in enumerate(values):
                self.history_table.setItem(r, c, QTableWidgetItem(v))


class BackupRestoreWindow(QWidget):
    def __init__(self, current_user):
        super().__init__()
        self.setWindowTitle("پشتیبان‌گیری و بازیابی")
        self.setLayoutDirection(Qt.LayoutDirection.RightToLeft)
        self.resize(900, 650)

        tabs = QTabWidget()
        tabs.addTab(BackupTab(current_user), "💾 پشتیبان‌گیری")
        tabs.addTab(RestoreTab(current_user), "♻️ بازیابی")

        layout = QVBoxLayout()
        layout.addWidget(tabs)
        self.setLayout(layout)
