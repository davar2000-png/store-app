# -*- coding: utf-8 -*-
"""پنجره «انتقال اطلاعات از نرم‌افزار قبلی» (Import) — اشخاص و کالاها"""

from PyQt6.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QTableWidget, QTableWidgetItem,
    QPushButton, QLabel, QComboBox, QTabWidget, QHeaderView,
    QFormLayout, QMessageBox, QFileDialog, QGroupBox, QTextEdit
)
from PyQt6.QtCore import Qt
import sys, os

sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
import services.import_service as imp
import services.inventory_service as inv

NO_MAP = "— نگاشت نشود —"


def make_table(headers):
    table = QTableWidget()
    table.setColumnCount(len(headers))
    table.setHorizontalHeaderLabels(headers)
    table.horizontalHeader().setSectionResizeMode(0, QHeaderView.ResizeMode.Stretch)
    table.setEditTriggers(QTableWidget.EditTrigger.NoEditTriggers)
    return table


class ImportRunTab(QWidget):
    def __init__(self, current_user, on_done):
        super().__init__()
        self.current_user = current_user
        self.on_done = on_done
        self.file_path = None
        self.source_type = "Access"
        self.loaded_rows = []
        self.source_table_name = ""
        self.mapping_widgets = {}
        self._build_ui()

    def _build_ui(self):
        layout = QVBoxLayout()

        # ۱) انتخاب منبع
        source_box = QGroupBox("۱) انتخاب فایل مبدأ")
        source_layout = QFormLayout()

        self.source_type_combo = QComboBox()
        self.source_type_combo.addItems(["Access (.mdb/.accdb)", "Excel (.xlsx)", "CSV"])
        self.source_type_combo.currentIndexChanged.connect(self._reset_after_source_change)
        source_layout.addRow("نوع فایل:", self.source_type_combo)

        file_row = QHBoxLayout()
        self.file_label = QLabel("(فایلی انتخاب نشده)")
        browse_btn = QPushButton("📂 انتخاب فایل...")
        browse_btn.clicked.connect(self.browse_file)
        file_row.addWidget(self.file_label)
        file_row.addWidget(browse_btn)
        source_layout.addRow("فایل:", file_row)

        self.table_combo = QComboBox()
        self.table_combo.currentIndexChanged.connect(self.load_selected_table)
        source_layout.addRow("جدول / شیت:", self.table_combo)

        source_box.setLayout(source_layout)
        layout.addWidget(source_box)

        # ۲) نوع اطلاعات مقصد
        target_box = QGroupBox("۲) این اطلاعات چه چیزی هستند؟")
        target_layout = QHBoxLayout()
        self.target_combo = QComboBox()
        self.target_combo.addItems(["👤 اشخاص (مشتری/فروشنده)", "📦 کالاها"])
        self.target_combo.currentIndexChanged.connect(self.build_mapping_form)
        target_layout.addWidget(self.target_combo)
        target_box.setLayout(target_layout)
        layout.addWidget(target_box)

        # ۳) نگاشت ستون‌ها
        self.mapping_box = QGroupBox("۳) هر فیلد را به ستون متناظرش در فایل مبدأ وصل کنید")
        self.mapping_layout = QFormLayout()
        self.mapping_box.setLayout(self.mapping_layout)
        layout.addWidget(self.mapping_box)

        # فقط برای کالاها: تأمین‌کننده موجودی اولیه
        self.supplier_row_widget = QWidget()
        supplier_row = QFormLayout()
        self.supplier_combo = QComboBox()
        supplier_row.addRow("تأمین‌کننده برای فاکتور «موجودی اولیه» (اختیاری):", self.supplier_combo)
        self.supplier_row_widget.setLayout(supplier_row)
        self.supplier_row_widget.setVisible(False)
        layout.addWidget(self.supplier_row_widget)

        btn_row = QHBoxLayout()
        preview_btn = QPushButton("🔍 پیش‌نمایش")
        preview_btn.clicked.connect(self.preview)
        run_btn = QPushButton("✅ اجرای Import")
        run_btn.setStyleSheet("font-weight: bold;")
        run_btn.clicked.connect(self.run_import)
        btn_row.addWidget(preview_btn)
        btn_row.addWidget(run_btn)
        layout.addLayout(btn_row)

        self.preview_table = make_table(["پیش‌نمایش"])
        layout.addWidget(self.preview_table)

        self.result_label = QLabel("")
        self.result_label.setWordWrap(True)
        layout.addWidget(self.result_label)

        self.setLayout(layout)
        self.build_mapping_form()

    # -----------------------------------------------------
    def _current_source_type(self) -> str:
        idx = self.source_type_combo.currentIndex()
        return ["Access", "Excel", "CSV"][idx]

    def _reset_after_source_change(self):
        self.file_path = None
        self.file_label.setText("(فایلی انتخاب نشده)")
        self.table_combo.clear()
        self.loaded_rows = []
        self.source_table_name = ""
        self.build_mapping_form()

    def browse_file(self):
        source_type = self._current_source_type()
        if source_type == "Access":
            filt = "Access Database (*.mdb *.accdb)"
        elif source_type == "Excel":
            filt = "Excel File (*.xlsx)"
        else:
            filt = "CSV File (*.csv)"

        path, _ = QFileDialog.getOpenFileName(self, "انتخاب فایل مبدأ", "", filt)
        if not path:
            return
        self.file_path = path
        self.file_label.setText(os.path.basename(path))
        self.table_combo.clear()
        self.loaded_rows = []

        try:
            if source_type == "Access":
                tables = imp.list_access_tables(path)
                self.table_combo.addItems(tables)
                self.table_combo.setEnabled(True)
            elif source_type == "Excel":
                sheets = imp.list_excel_sheets(path)
                self.table_combo.addItems(sheets)
                self.table_combo.setEnabled(True)
            else:  # CSV
                self.table_combo.setEnabled(False)
                self.loaded_rows = imp.read_csv_file(path)
                self.source_table_name = os.path.basename(path)
                self.build_mapping_form()
        except Exception as e:
            QMessageBox.critical(self, "خطا", str(e))

    def load_selected_table(self):
        source_type = self._current_source_type()
        if source_type == "CSV" or not self.file_path or self.table_combo.currentText() == "":
            return
        name = self.table_combo.currentText()
        try:
            if source_type == "Access":
                self.loaded_rows = imp.read_access_table(self.file_path, name)
            elif source_type == "Excel":
                self.loaded_rows = imp.read_excel_sheet(self.file_path, name)
            self.source_table_name = name
            self.build_mapping_form()
        except Exception as e:
            QMessageBox.critical(self, "خطا", str(e))

    # -----------------------------------------------------
    def _target_fields(self):
        return imp.PERSON_FIELDS if self.target_combo.currentIndex() == 0 else imp.PRODUCT_FIELDS

    def build_mapping_form(self):
        while self.mapping_layout.rowCount():
            self.mapping_layout.removeRow(0)
        self.mapping_widgets = {}

        columns = imp.get_source_columns(self.loaded_rows)
        is_products = self.target_combo.currentIndex() == 1
        self.supplier_row_widget.setVisible(is_products)
        if is_products and self.supplier_combo.count() == 0:
            self._load_suppliers()

        for key, label, required in self._target_fields():
            combo = QComboBox()
            combo.addItem(NO_MAP)
            combo.addItems(columns)
            # حدس اولیه: اگر نام ستونی شبیه کلید فیلد بود، خودکار انتخابش کن
            for i, col in enumerate(columns):
                if col.strip().lower() == key.lower():
                    combo.setCurrentIndex(i + 1)
                    break
            self.mapping_widgets[key] = combo
            self.mapping_layout.addRow(label, combo)

        if not columns:
            info = QLabel("ابتدا فایل و جدول/شیت مبدأ را انتخاب کنید تا ستون‌ها اینجا نمایش داده شود.")
            self.mapping_layout.addRow(info)

    def _load_suppliers(self):
        self.supplier_combo.clear()
        self.supplier_combo.addItem("(بدون تأمین‌کننده — موجودی اولیه ثبت نشود)", None)
        try:
            for s in inv.get_suppliers():
                self.supplier_combo.addItem(s["FullName"], s["ID"])
        except Exception:
            pass

    def _current_mapping(self) -> dict:
        mapping = {}
        for key, combo in self.mapping_widgets.items():
            val = combo.currentText()
            mapping[key] = None if val == NO_MAP else val
        return mapping

    # -----------------------------------------------------
    def preview(self):
        if not self.loaded_rows:
            QMessageBox.warning(self, "توجه", "ابتدا فایل مبدأ را انتخاب کنید.")
            return
        mapping = self._current_mapping()
        rows = imp.preview_rows(self.loaded_rows, mapping, limit=10)
        fields = [k for k, _, _ in self._target_fields()]
        self.preview_table.setColumnCount(len(fields))
        self.preview_table.setHorizontalHeaderLabels(fields)
        self.preview_table.setRowCount(len(rows))
        for r, row in enumerate(rows):
            for c, key in enumerate(fields):
                val = row.get(key)
                self.preview_table.setItem(r, c, QTableWidgetItem("" if val is None else str(val)))

    def run_import(self):
        if not self.loaded_rows:
            QMessageBox.warning(self, "توجه", "ابتدا فایل مبدأ را انتخاب کنید.")
            return

        mapping = self._current_mapping()
        is_products = self.target_combo.currentIndex() == 1
        required_ok = True
        for key, label, required in self._target_fields():
            if required and not mapping.get(key):
                required_ok = False
        if not required_ok:
            QMessageBox.warning(self, "توجه", "فیلد(های) اجباری باید نگاشت شوند (مثلاً نام).")
            return

        confirm = QMessageBox.question(
            self, "تأیید Import",
            f"{len(self.loaded_rows)} ردیف بررسی و درج می‌شود. ادامه می‌دهید؟",
            QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No
        )
        if confirm != QMessageBox.StandardButton.Yes:
            return

        try:
            if is_products:
                supplier_id = self.supplier_combo.currentData()
                result = imp.import_products(
                    self.loaded_rows, mapping, self.current_user["ID"], supplier_id=supplier_id,
                    source_type=self._current_source_type(),
                    source_file=os.path.basename(self.file_path or ""),
                    source_table=self.source_table_name
                )
            else:
                result = imp.import_persons(
                    self.loaded_rows, mapping, self.current_user["ID"],
                    source_type=self._current_source_type(),
                    source_file=os.path.basename(self.file_path or ""),
                    source_table=self.source_table_name
                )
        except Exception as e:
            QMessageBox.critical(self, "خطا", f"Import ناموفق بود:\n{e}")
            return

        msg = f"✅ موفق: {result['success']}   |   ❌ ناموفق/رد شده: {result['failed']}   |   جمع: {result['total']}"
        extra = ""
        if result.get("errors"):
            extra += "\n\nنمونه خطاها:\n" + "\n".join(result["errors"][:15])
        if result.get("warnings"):
            extra += "\n\nهشدارها:\n" + "\n".join(result["warnings"][:15])
        self.result_label.setText(msg + extra)
        QMessageBox.information(self, "نتیجه Import", msg)
        if self.on_done:
            self.on_done()


class ImportHistoryTab(QWidget):
    def __init__(self):
        super().__init__()
        self._build_ui()
        self.load_data()

    def _build_ui(self):
        layout = QVBoxLayout()
        refresh_btn = QPushButton("🔄 بروزرسانی")
        refresh_btn.clicked.connect(self.load_data)
        layout.addWidget(refresh_btn)

        self.table = make_table(
            ["تاریخ", "نوع منبع", "فایل", "جدول/شیت", "مقصد", "کل", "موفق", "ناموفق"]
        )
        layout.addWidget(self.table)

        self.detail_box = QTextEdit()
        self.detail_box.setReadOnly(True)
        self.detail_box.setPlaceholderText("برای دیدن جزئیات خطاهای یک ردیف، آن را انتخاب کنید...")
        layout.addWidget(self.detail_box)

        self.table.itemSelectionChanged.connect(self._show_detail)
        self.setLayout(layout)

    def load_data(self):
        self.rows = imp.get_import_history()
        self.table.setRowCount(len(self.rows))
        for r, row in enumerate(self.rows):
            values = [
                row["ShamsiDate"] or "", row["SourceType"] or "", row["SourceFile"] or "",
                row["SourceTable"] or "", row["TargetEntity"] or "",
                str(row["TotalRows"]), str(row["SuccessRows"]), str(row["FailedRows"])
            ]
            for c, v in enumerate(values):
                self.table.setItem(r, c, QTableWidgetItem(v))

    def _show_detail(self):
        idx = self.table.currentRow()
        if idx < 0 or idx >= len(self.rows):
            return
        self.detail_box.setPlainText(self.rows[idx]["ErrorDetails"] or "(خطا/هشداری ثبت نشده)")


class ImportWindow(QWidget):
    def __init__(self, current_user):
        super().__init__()
        self.current_user = current_user
        self.setWindowTitle("انتقال اطلاعات از نرم‌افزار قبلی (Import)")
        self.setLayoutDirection(Qt.LayoutDirection.RightToLeft)
        self.resize(950, 700)

        tabs = QTabWidget()
        self.history_tab = ImportHistoryTab()
        self.run_tab = ImportRunTab(current_user, on_done=self.history_tab.load_data)
        tabs.addTab(self.run_tab, "📥 Import جدید")
        tabs.addTab(self.history_tab, "🕘 تاریخچه")

        layout = QVBoxLayout()
        layout.addWidget(tabs)
        self.setLayout(layout)
