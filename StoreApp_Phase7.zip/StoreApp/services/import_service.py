# -*- coding: utf-8 -*-
"""
لایه منطق تجاری «انتقال اطلاعات از نرم‌افزار قبلی» (Import).
از سه نوع منبع پشتیبانی می‌شود: دیتابیس Access (.mdb/.accdb)، فایل اکسل (.xlsx)
و فایل CSV. چون ساختار دیتابیس نرم‌افزار قبلی برای ما مشخص نیست، کاربر خودش
از داخل برنامه ستون‌های فایل مبدأ را به فیلدهای «اشخاص» یا «کالاها» نگاشت
(map) می‌کند؛ به همین دلیل نیازی به دانستن ساختار دقیق نرم‌افزار قبلی نیست.
"""

import sys
import os
import csv
import io

sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from database.db import Database
from utils.persian_date import today_shamsi_str
import services.inventory_service as inv


class ImportError_(Exception):
    """خطای قابل‌فهم برای نمایش به کاربر"""
    pass


# =========================================================
# فیلدهای مقصد (چیزهایی که می‌شود نگاشت کرد)
# هر آیتم: (کلید فیلد, برچسب فارسی, آیا اجباری است)
# =========================================================
PERSON_FIELDS = [
    ("FullName", "نام کامل / نام شرکت (اجباری)", True),
    ("Mobile", "موبایل", False),
    ("Phone", "تلفن ثابت", False),
    ("NationalCode", "کد ملی", False),
    ("Address", "آدرس", False),
    ("IsCustomer", "مشتری است؟ (1/0 یا بله/خیر)", False),
    ("IsSeller", "فروشنده/تأمین‌کننده است؟ (1/0 یا بله/خیر)", False),
]

PRODUCT_FIELDS = [
    ("Name", "نام کالا (اجباری)", True),
    ("Code", "کد کالا", False),
    ("Brand", "برند", False),
    ("Model", "مدل", False),
    ("BarCode", "بارکد", False),
    ("PurchasePrice", "قیمت خرید", False),
    ("SalePrice", "قیمت فروش", False),
    ("OrderPoint", "نقطه سفارش", False),
    ("InitialStock", "موجودی اولیه (تعداد) — اختیاری", False),
]


# =========================================================
# خواندن منبع: Access
# =========================================================
def _access_connect(file_path: str):
    import pyodbc
    if not os.path.exists(file_path):
        raise ImportError_(f"فایل پیدا نشد: {file_path}")
    conn_str = (
        r"DRIVER={Microsoft Access Driver (*.mdb, *.accdb)};"
        f"DBQ={file_path};"
    )
    try:
        return pyodbc.connect(conn_str, autocommit=True)
    except Exception as e:
        raise ImportError_(
            "اتصال به فایل Access ناموفق بود. مطمئن شوید «Microsoft Access "
            "Database Engine» (نسخه ۳۲ یا ۶۴ بیتی، متناسب با پایتون شما) نصب "
            f"است.\nجزئیات خطا: {e}"
        )


def list_access_tables(file_path: str) -> list:
    conn = _access_connect(file_path)
    try:
        cursor = conn.cursor()
        tables = []
        for row in cursor.tables(tableType="TABLE"):
            name = row.table_name
            if name.startswith("MSys") or name.startswith("~"):
                continue
            tables.append(name)
        return sorted(tables)
    finally:
        conn.close()


def read_access_table(file_path: str, table_name: str) -> list:
    conn = _access_connect(file_path)
    try:
        cursor = conn.cursor()
        # نام جدول را با [] احاطه می‌کنیم چون ممکن است فاصله یا کاراکتر خاص داشته باشد
        cursor.execute(f"SELECT * FROM [{table_name}]")
        columns = [c[0] for c in cursor.description]
        rows = [dict(zip(columns, r)) for r in cursor.fetchall()]
        return rows
    finally:
        conn.close()


# =========================================================
# خواندن منبع: Excel
# =========================================================
def list_excel_sheets(file_path: str) -> list:
    from openpyxl import load_workbook
    wb = load_workbook(file_path, read_only=True, data_only=True)
    try:
        return list(wb.sheetnames)
    finally:
        wb.close()


def read_excel_sheet(file_path: str, sheet_name: str) -> list:
    from openpyxl import load_workbook
    wb = load_workbook(file_path, read_only=True, data_only=True)
    try:
        ws = wb[sheet_name]
        rows_iter = ws.iter_rows(values_only=True)
        try:
            header = [str(h).strip() if h is not None else f"ستون{i+1}"
                      for i, h in enumerate(next(rows_iter))]
        except StopIteration:
            return []
        result = []
        for r in rows_iter:
            if r is None or all(v is None for v in r):
                continue
            result.append(dict(zip(header, r)))
        return result
    finally:
        wb.close()


# =========================================================
# خواندن منبع: CSV
# =========================================================
def read_csv_file(file_path: str) -> list:
    with open(file_path, "rb") as f:
        raw = f.read()
    text = raw.decode("utf-8-sig", errors="replace")
    sample = text[:4096]
    try:
        dialect = csv.Sniffer().sniff(sample, delimiters=",;\t")
    except Exception:
        class _Default(csv.Dialect):
            delimiter = ","
            quotechar = '"'
            doublequote = True
            skipinitialspace = False
            lineterminator = "\r\n"
            quoting = csv.QUOTE_MINIMAL
        dialect = _Default
    reader = csv.DictReader(io.StringIO(text), dialect=dialect)
    rows = [row for row in reader]
    return rows


# =========================================================
# توابع کمکی
# =========================================================
def get_source_columns(rows: list) -> list:
    """ستون‌های موجود در ردیف‌های خوانده‌شده (از اولین ردیف)"""
    if not rows:
        return []
    return list(rows[0].keys())


def _clean_str(v) -> str:
    if v is None:
        return ""
    return str(v).strip()


def _to_float(v, default=0.0) -> float:
    s = _clean_str(v).replace(",", "")
    if s == "":
        return default
    try:
        return float(s)
    except ValueError:
        return default


def _to_bool(v, default=False) -> bool:
    s = _clean_str(v).lower()
    if s == "":
        return default
    return s in ("1", "true", "yes", "بله", "y", "ok")


def apply_mapping(row: dict, mapping: dict) -> dict:
    """mapping: {target_field: source_column_name_or_None}"""
    out = {}
    for target, source_col in mapping.items():
        if source_col:
            out[target] = row.get(source_col)
        else:
            out[target] = None
    return out


def preview_rows(rows: list, mapping: dict, limit: int = 10) -> list:
    return [apply_mapping(r, mapping) for r in rows[:limit]]


def log_import(source_type, source_file, source_table, target_entity,
                total, success, failed, error_details, user_id):
    db = Database()
    db.execute(
        """INSERT INTO ImportLog
           (ShamsiDate, SourceType, SourceFile, SourceTable, TargetEntity,
            TotalRows, SuccessRows, FailedRows, ErrorDetails, UserRef)
           VALUES (?,?,?,?,?,?,?,?,?,?)""",
        (today_shamsi_str(), source_type, source_file, source_table, target_entity,
         total, success, failed, error_details, user_id)
    )
    db.close()


def get_import_history():
    db = Database()
    rows = db.fetch_all(
        """SELECT TOP 200 ShamsiDate, SourceType, SourceFile, SourceTable, TargetEntity,
                  TotalRows, SuccessRows, FailedRows, ErrorDetails
           FROM ImportLog ORDER BY ID DESC"""
    )
    db.close()
    return rows


# =========================================================
# Import اشخاص
# =========================================================
def import_persons(rows: list, mapping: dict, user_id: int,
                    source_type: str = "", source_file: str = "", source_table: str = ""):
    """
    rows: لیست دیکشنری (ردیف‌های خام فایل مبدأ)
    mapping: {target_field: source_column_name_or_None} بر اساس PERSON_FIELDS
    خروجی: dict با کلیدهای total, success, failed, errors(list of str)
    """
    db = Database()
    total = len(rows)
    success = 0
    failed = 0
    errors = []

    for idx, raw in enumerate(rows, start=1):
        m = apply_mapping(raw, mapping)
        full_name = _clean_str(m.get("FullName"))
        if not full_name:
            failed += 1
            errors.append(f"ردیف {idx}: نام خالی است — رد شد.")
            continue

        mobile = _clean_str(m.get("Mobile"))
        national_code = _clean_str(m.get("NationalCode"))

        # جلوگیری از ثبت دوباره بر اساس موبایل یا کد ملی (اگر موجود بود)
        try:
            if mobile:
                dup = db.fetch_one(
                    "SELECT ID FROM Persons WHERE Mobile = ? AND IsDeleted = 0", (mobile,)
                )
                if dup:
                    failed += 1
                    errors.append(f"ردیف {idx} ({full_name}): موبایل تکراری است — رد شد.")
                    continue
            if national_code:
                dup = db.fetch_one(
                    "SELECT ID FROM Persons WHERE NationalCode = ? AND IsDeleted = 0", (national_code,)
                )
                if dup:
                    failed += 1
                    errors.append(f"ردیف {idx} ({full_name}): کد ملی تکراری است — رد شد.")
                    continue

            is_customer = _to_bool(m.get("IsCustomer"), default=True)
            is_seller = _to_bool(m.get("IsSeller"), default=False)

            db.execute(
                """INSERT INTO Persons
                   (FullName, Mobile, Phone, NationalCode, Address,
                    IsCustomer, IsSeller, CreatedShamsiDate)
                   VALUES (?,?,?,?,?,?,?,?)""",
                (full_name, mobile, _clean_str(m.get("Phone")), national_code,
                 _clean_str(m.get("Address")), int(is_customer), int(is_seller),
                 today_shamsi_str())
            )
            success += 1
        except Exception as e:
            failed += 1
            errors.append(f"ردیف {idx} ({full_name}): خطا — {e}")

    db.close()

    error_text = "\n".join(errors[:500])
    log_import(source_type, source_file, source_table, "Persons",
               total, success, failed, error_text, user_id)

    return {"total": total, "success": success, "failed": failed, "errors": errors}


# =========================================================
# Import کالاها (+ موجودی اولیه اختیاری)
# =========================================================
def import_products(rows: list, mapping: dict, user_id: int, supplier_id=None,
                     source_type: str = "", source_file: str = "", source_table: str = ""):
    """
    اگر مقدار «موجودی اولیه» برای یک کالا بزرگ‌تر از صفر باشد و supplier_id داده
    شده باشد، یک فاکتور خرید (ورودی اولیه) خودکار برای آن کالا ساخته می‌شود
    تا موجودی، کاردکس و لایه FIFO آن هم مثل بقیه کالاها درست باشد.
    """
    db = Database()
    total = len(rows)
    success = 0
    failed = 0
    errors = []
    stock_warnings = []

    for idx, raw in enumerate(rows, start=1):
        m = apply_mapping(raw, mapping)
        name = _clean_str(m.get("Name"))
        if not name:
            failed += 1
            errors.append(f"ردیف {idx}: نام کالا خالی است — رد شد.")
            continue

        code = _clean_str(m.get("Code"))
        barcode = _clean_str(m.get("BarCode"))

        try:
            if code:
                dup = db.fetch_one(
                    "SELECT ID FROM Products WHERE Code = ? AND IsDeleted = 0", (code,)
                )
                if dup:
                    failed += 1
                    errors.append(f"ردیف {idx} ({name}): کد کالا تکراری است — رد شد.")
                    continue
            if barcode:
                dup = db.fetch_one(
                    "SELECT ID FROM Products WHERE BarCode = ? AND IsDeleted = 0", (barcode,)
                )
                if dup:
                    failed += 1
                    errors.append(f"ردیف {idx} ({name}): بارکد تکراری است — رد شد.")
                    continue

            purchase_price = _to_float(m.get("PurchasePrice"), 0)
            sale_price = _to_float(m.get("SalePrice"), 0)
            order_point = _to_float(m.get("OrderPoint"), 0)
            initial_stock = _to_float(m.get("InitialStock"), 0)

            new_id = db.execute(
                """INSERT INTO Products
                   (Name, Code, Brand, Model, BarCode, PurchasePrice, SalePrice, OrderPoint)
                   VALUES (?,?,?,?,?,?,?,?)""",
                (name, code, _clean_str(m.get("Brand")), _clean_str(m.get("Model")),
                 barcode, purchase_price, sale_price, order_point)
            )
            success += 1

            if initial_stock > 0:
                if not supplier_id:
                    stock_warnings.append(
                        f"ردیف {idx} ({name}): کالا ساخته شد ولی چون تأمین‌کننده‌ای برای "
                        "فاکتور ورودی اولیه انتخاب نشده بود، موجودی اولیه ثبت نشد."
                    )
                else:
                    try:
                        product_id = new_id
                        if not product_id:
                            row = db.fetch_one(
                                "SELECT TOP 1 ID FROM Products WHERE Code = ? ORDER BY ID DESC", (code,)
                            ) if code else db.fetch_one(
                                "SELECT TOP 1 ID FROM Products WHERE Name = ? ORDER BY ID DESC", (name,)
                            )
                            product_id = row["ID"] if row else None
                        if product_id:
                            inv.create_purchase_invoice(
                                supplier_id=supplier_id,
                                shamsi_date=today_shamsi_str(),
                                discount_amount=0,
                                tax_amount=0,
                                description=f"موجودی اولیه Import — {name}",
                                user_id=user_id,
                                items=[{
                                    "product_id": product_id,
                                    "quantity": initial_stock,
                                    "unit_price": purchase_price,
                                    "has_serial": False,
                                }]
                            )
                    except Exception as e:
                        stock_warnings.append(
                            f"ردیف {idx} ({name}): کالا ساخته شد ولی ثبت موجودی اولیه خطا داد — {e}"
                        )
        except Exception as e:
            failed += 1
            errors.append(f"ردیف {idx} ({name}): خطا — {e}")

    db.close()

    all_notes = errors + stock_warnings
    error_text = "\n".join(all_notes[:500])
    log_import(source_type, source_file, source_table, "Products",
               total, success, failed, error_text, user_id)

    return {
        "total": total, "success": success, "failed": failed,
        "errors": errors, "warnings": stock_warnings,
    }
