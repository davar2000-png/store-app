# -*- coding: utf-8 -*-
"""
لایه منطق تجاری «پشتیبان‌گیری و بازیابی کامل دیتابیس».
از دستورات بومی SQL Server (BACKUP DATABASE / RESTORE DATABASE) استفاده
می‌شود، یعنی خروجی یک فایل استاندارد .bak است که خود SSMS هم می‌تواند
آن را باز/بازیابی کند (خیال شما از این بابت راحت باشد).

نکته مهم: مسیر پوشه‌ی پشتیبان باید توسط «سرویس SQL Server» قابل‌نوشتن باشد،
نه فقط توسط کاربر ویندوز شما؛ به همین دلیل بهتر است یک پوشه‌ی ساده و محلی
(مثل C:\\StoreAppBackups) روی همان کامپیوتری که SQL Server رویش نصب است
انتخاب کنید.
"""

import sys
import os
import datetime

sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from database.db import Database
from utils.persian_date import today_shamsi_str
import config

DATABASE_NAME = config.SQL_DATABASE


class BackupError(Exception):
    pass


def get_backup_folder() -> str:
    db = Database()
    row = db.fetch_one("SELECT SettingValue FROM Settings WHERE SettingKey = N'BackupFolderPath'")
    db.close()
    return row["SettingValue"] if row and row["SettingValue"] else r"C:\StoreAppBackups"


def set_backup_folder(path: str):
    db = Database()
    existing = db.fetch_one("SELECT ID FROM Settings WHERE SettingKey = N'BackupFolderPath'")
    if existing:
        db.execute("UPDATE Settings SET SettingValue = ? WHERE SettingKey = N'BackupFolderPath'", (path,))
    else:
        db.execute(
            "INSERT INTO Settings (SettingKey, SettingValue, Description) VALUES (N'BackupFolderPath', ?, N'مسیر پوشه پشتیبان')",
            (path,)
        )
    db.close()


def _log(action_type, file_path, size_mb, status, error_message, user_id):
    db = Database()
    db.execute(
        """INSERT INTO BackupLog
           (ActionType, ShamsiDate, FilePath, FileSizeMB, Status, ErrorMessage, UserRef)
           VALUES (?,?,?,?,?,?,?)""",
        (action_type, today_shamsi_str(), file_path, size_mb, status, error_message, user_id)
    )
    db.close()


def get_backup_history():
    db = Database()
    rows = db.fetch_all(
        """SELECT TOP 200 ActionType, ShamsiDate, FilePath, FileSizeMB, Status, ErrorMessage
           FROM BackupLog ORDER BY ID DESC"""
    )
    db.close()
    return rows


def backup_database(folder_path: str, user_id: int) -> str:
    """
    یک نسخه پشتیبان کامل از دیتابیس می‌گیرد و مسیر فایل ساخته‌شده را برمی‌گرداند.
    توجه: این عملیات روی سرور SQL انجام می‌شود، پس مسیر باید برای سرویس SQL
    Server قابل‌نوشتن باشد (نه لزوماً برای برنامه پایتون).
    """
    if not folder_path:
        raise BackupError("مسیر پوشه پشتیبان مشخص نشده است.")

    timestamp = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
    file_name = f"{DATABASE_NAME}_{timestamp}.bak"
    # از بک‌اسلش ویندوزی استفاده می‌کنیم چون SQL Server معمولاً روی ویندوز است
    sep = "\\" if "\\" in folder_path or ":" in folder_path else os.sep
    full_path = folder_path.rstrip("\\/") + sep + file_name

    db = Database(database="master")
    try:
        conn = db.connect()
        conn.autocommit = True
        cursor = conn.cursor()
        cursor.execute(
            f"BACKUP DATABASE [{DATABASE_NAME}] TO DISK = ? WITH INIT, NAME = ?",
            (full_path, f"{DATABASE_NAME}-Full-{timestamp}")
        )
        cursor.close()
        db.close()

        size_mb = None
        try:
            if os.path.exists(full_path):
                size_mb = round(os.path.getsize(full_path) / (1024 * 1024), 2)
        except Exception:
            pass

        _log("Backup", full_path, size_mb, "Success", None, user_id)
        return full_path
    except Exception as e:
        db.close()
        _log("Backup", full_path, None, "Failed", str(e), user_id)
        raise BackupError(
            "تهیه نسخه پشتیبان ناموفق بود. معمولاً دلیلش این است که سرویس SQL "
            "Server به مسیر انتخابی دسترسی نوشتن ندارد.\n"
            f"جزئیات خطا: {e}"
        )


def restore_database(backup_file_path: str, user_id: int):
    """
    دیتابیس را از روی فایل .bak بازیابی می‌کند.
    ⚠️ این عملیات مخرب است: تمام اطلاعات فعلی با اطلاعات داخل فایل پشتیبان
    جایگزین می‌شود. قبل از فراخوانی این تابع باید در رابط کاربری از کاربر
    تأییدیه صریح گرفته شود و همه پنجره‌های دیگر برنامه بسته شوند.
    """
    if not backup_file_path:
        raise BackupError("فایل پشتیبان مشخص نشده است.")

    db = Database(database="master")
    try:
        conn = db.connect()
        conn.autocommit = True
        cursor = conn.cursor()

        cursor.execute(
            f"ALTER DATABASE [{DATABASE_NAME}] SET SINGLE_USER WITH ROLLBACK IMMEDIATE"
        )
        cursor.execute(
            f"RESTORE DATABASE [{DATABASE_NAME}] FROM DISK = ? WITH REPLACE",
            (backup_file_path,)
        )
        cursor.execute(
            f"ALTER DATABASE [{DATABASE_NAME}] SET MULTI_USER"
        )
        cursor.close()
        db.close()

        size_mb = None
        try:
            if os.path.exists(backup_file_path):
                size_mb = round(os.path.getsize(backup_file_path) / (1024 * 1024), 2)
        except Exception:
            pass

        _log("Restore", backup_file_path, size_mb, "Success", None, user_id)
    except Exception as e:
        try:
            # تلاش برای برگرداندن دیتابیس به حالت چند-کاربره حتی اگر بازیابی خطا داد
            conn2 = Database(database="master")
            c2 = conn2.connect()
            c2.autocommit = True
            c2.cursor().execute(f"ALTER DATABASE [{DATABASE_NAME}] SET MULTI_USER")
            conn2.close()
        except Exception:
            pass
        _log("Restore", backup_file_path, None, "Failed", str(e), user_id)
        raise BackupError(
            "بازیابی دیتابیس ناموفق بود. مطمئن شوید هیچ برنامه‌ی دیگری (از جمله "
            "خود StoreApp روی سایر سیستم‌ها) به دیتابیس وصل نیست و فایل پشتیبان "
            f"سالم است.\nجزئیات خطا: {e}"
        )


def list_backup_files(folder_path: str) -> list:
    """لیست فایل‌های .bak موجود در پوشه (اگر پوشه از همین کامپیوتر قابل‌خواندن باشد)"""
    result = []
    try:
        if os.path.isdir(folder_path):
            for fname in sorted(os.listdir(folder_path), reverse=True):
                if fname.lower().endswith(".bak"):
                    full = os.path.join(folder_path, fname)
                    try:
                        size_mb = round(os.path.getsize(full) / (1024 * 1024), 2)
                        mtime = datetime.datetime.fromtimestamp(os.path.getmtime(full))
                    except Exception:
                        size_mb, mtime = None, None
                    result.append({"name": fname, "path": full, "size_mb": size_mb, "modified": mtime})
    except Exception:
        pass
    return result
