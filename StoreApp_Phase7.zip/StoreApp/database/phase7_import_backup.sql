-- =========================================================
-- نرم‌افزار حسابداری فروشگاه موبایل، لپ‌تاپ و کنسول بازی
-- مرحله ۷: انتقال اطلاعات از نرم‌افزار قبلی (Import) + پشتیبان‌گیری/بازیابی کامل
-- =========================================================
-- این فایل فقط جدول‌های جدید را اضافه می‌کند و به داده‌های قبلی
-- هیچ آسیبی نمی‌رساند.
-- =========================================================

USE StoreAppDB;
GO

-- =========================================================
-- ۱) تاریخچه Import (هر بار که فایلی وارد سیستم شود، یک ردیف اینجا ثبت می‌شود)
-- =========================================================
IF OBJECT_ID('ImportLog', 'U') IS NULL
BEGIN
    CREATE TABLE ImportLog (
        ID              INT IDENTITY(1,1) PRIMARY KEY,
        ImportDate      DATETIME2 NOT NULL DEFAULT GETDATE(),
        ShamsiDate      NVARCHAR(20) NULL,
        SourceType      NVARCHAR(50) NOT NULL,      -- Access, Excel, CSV
        SourceFile      NVARCHAR(500) NULL,
        SourceTable     NVARCHAR(200) NULL,          -- نام جدول/شیت مبدأ
        TargetEntity    NVARCHAR(50) NOT NULL,       -- Persons, Products
        TotalRows       INT NOT NULL DEFAULT 0,
        SuccessRows     INT NOT NULL DEFAULT 0,
        FailedRows      INT NOT NULL DEFAULT 0,
        ErrorDetails    NVARCHAR(MAX) NULL,          -- خلاصه خطاهای هر ردیف (اگر بود)
        UserRef         INT NULL FOREIGN KEY REFERENCES Users(ID),
        CreatedAt       DATETIME2 NOT NULL DEFAULT GETDATE()
    );
END
GO

-- =========================================================
-- ۲) تاریخچه پشتیبان‌گیری / بازیابی
-- =========================================================
IF OBJECT_ID('BackupLog', 'U') IS NULL
BEGIN
    CREATE TABLE BackupLog (
        ID              INT IDENTITY(1,1) PRIMARY KEY,
        ActionType      NVARCHAR(20) NOT NULL,       -- Backup, Restore
        ActionDate      DATETIME2 NOT NULL DEFAULT GETDATE(),
        ShamsiDate      NVARCHAR(20) NULL,
        FilePath        NVARCHAR(500) NULL,
        FileSizeMB      DECIMAL(18,2) NULL,
        Status          NVARCHAR(20) NOT NULL,       -- Success, Failed
        ErrorMessage    NVARCHAR(MAX) NULL,
        UserRef         INT NULL FOREIGN KEY REFERENCES Users(ID),
        CreatedAt       DATETIME2 NOT NULL DEFAULT GETDATE()
    );
END
GO

-- =========================================================
-- ۳) تنظیم پیش‌فرض مسیر پشتیبان‌گیری (اگر قبلاً وجود نداشت)
-- =========================================================
IF NOT EXISTS (SELECT * FROM Settings WHERE SettingKey = N'BackupFolderPath')
BEGIN
    INSERT INTO Settings (SettingKey, SettingValue, Description)
    VALUES (N'BackupFolderPath', N'C:\StoreAppBackups', N'مسیر پوشه‌ی ذخیره فایل‌های پشتیبان (.bak)');
END
GO

PRINT N'✅ جداول مرحله ۷ (Import و پشتیبان‌گیری/بازیابی) با موفقیت ساخته شد.';
