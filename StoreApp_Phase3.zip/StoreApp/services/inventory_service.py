# -*- coding: utf-8 -*-
"""
لایه منطق تجاری «خرید و انبار».
همه محاسبات FIFO، کاردکس، موجودی و سریال/IMEI اینجا انجام می‌شود
تا پنجره‌های UI فقط نمایش‌دهنده باشند و منطق اصلی یک‌جا و قابل‌اعتماد بماند.
"""

import sys
import os

sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from database.db import Database


class InventoryError(Exception):
    """خطای قابل‌فهم برای نمایش به کاربر (نه خطای فنی دیتابیس)"""
    pass


def get_suppliers():
    """لیست اشخاصی که به‌عنوان فروشنده/تأمین‌کننده علامت خورده‌اند"""
    db = Database()
    rows = db.fetch_all(
        "SELECT ID, FullName FROM Persons WHERE IsSeller = 1 AND IsDeleted = 0 ORDER BY FullName"
    )
    db.close()
    return rows


def search_products(text: str = ""):
    """جستجوی کالا برای انتخاب در فاکتور خرید"""
    db = Database()
    like = f"%{text.strip()}%"
    rows = db.fetch_all(
        """SELECT ID, Name, Code, Brand, Model, HasSerial, CurrentStock, PurchasePrice, OrderPoint
           FROM Products
           WHERE IsDeleted = 0 AND (Name LIKE ? OR Code LIKE ? OR Brand LIKE ?)
           ORDER BY Name""",
        (like, like, like)
    )
    db.close()
    return rows


def get_low_stock_products():
    """کالاهایی که موجودی‌شان به نقطه سفارش رسیده یا کمتر شده"""
    db = Database()
    rows = db.fetch_all(
        """SELECT ID, Name, Code, CurrentStock, OrderPoint
           FROM Products
           WHERE IsDeleted = 0 AND OrderPoint > 0 AND CurrentStock <= OrderPoint
           ORDER BY Name"""
    )
    db.close()
    return rows


def get_purchase_invoices(search: str = ""):
    db = Database()
    like = f"%{search.strip()}%"
    rows = db.fetch_all(
        """SELECT pi.ID, pi.InvoiceNumber, pi.ShamsiDate, p.FullName AS SupplierName,
                  pi.PayableAmount, pi.Description
           FROM PurchaseInvoices pi
           JOIN Persons p ON p.ID = pi.PersonRef
           WHERE pi.IsDeleted = 0 AND
                 (CAST(pi.InvoiceNumber AS NVARCHAR(50)) LIKE ? OR p.FullName LIKE ?)
           ORDER BY pi.ID DESC""",
        (like, like)
    )
    db.close()
    return rows


def get_invoice_items(invoice_id: int):
    db = Database()
    rows = db.fetch_all(
        """SELECT pii.ID, pr.Name AS ProductName, pii.Quantity, pii.UnitPrice,
                  pii.DiscountAmount, pii.TotalPrice
           FROM PurchaseInvoiceItems pii
           JOIN Products pr ON pr.ID = pii.ProductRef
           WHERE pii.InvoiceRef = ?
           ORDER BY pii.ID""",
        (invoice_id,)
    )
    db.close()
    return rows


def get_product_cardex(product_id: int):
    """گزارش کاردکس یک کالا (تاریخچه کامل ورود/خروج)"""
    db = Database()
    rows = db.fetch_all(
        """SELECT ShamsiDate, MovementType, InQuantity, OutQuantity,
                  UnitPrice, BalanceQuantity, Description
           FROM ProductCardex
           WHERE ProductRef = ?
           ORDER BY ID""",
        (product_id,)
    )
    db.close()
    return rows


def serial_exists_in_stock(serial: str) -> bool:
    db = Database()
    row = db.fetch_one(
        "SELECT COUNT(*) AS c FROM ProductSerials WHERE SerialNumber = ? AND Status = N'InStock'",
        (serial,)
    )
    db.close()
    return bool(row and row["c"] > 0)


def create_purchase_invoice(supplier_id: int, shamsi_date: str, discount_amount: float,
                             tax_amount: float, description: str, user_id: int, items: list):
    """
    ثبت یک فاکتور خرید کامل به‌صورت یکپارچه (Transaction):
    سربرگ فاکتور + اقلام + لایه FIFO + سریال/IMEI + بروزرسانی موجودی + کاردکس.
    اگر هر بخشی با خطا مواجه شود، هیچ‌کدام ذخیره نمی‌شود (rollback کامل).

    items: لیستی از دیکشنری با کلیدهای:
        product_id, quantity, unit_price, discount (اختیاری), serials (لیست رشته یا None)
    """
    if not items:
        raise InventoryError("حداقل یک قلم کالا باید به فاکتور اضافه شود.")

    for item in items:
        qty = float(item.get("quantity") or 0)
        if qty <= 0:
            raise InventoryError("تعداد هر قلم کالا باید بزرگ‌تر از صفر باشد.")
        if float(item.get("unit_price") or 0) < 0:
            raise InventoryError("قیمت خرید نمی‌تواند منفی باشد.")
        serials = item.get("serials") or []
        if item.get("has_serial") and len(serials) != int(qty):
            raise InventoryError(
                f"برای «{item.get('product_name', 'کالا')}» باید دقیقاً {int(qty)} سریال/IMEI وارد شود."
            )

    db = Database()
    conn = db.connect()
    cursor = conn.cursor()
    try:
        total_amount = sum(
            float(i["quantity"]) * float(i["unit_price"]) - float(i.get("discount", 0) or 0)
            for i in items
        )
        payable = total_amount - float(discount_amount or 0) + float(tax_amount or 0)

        cursor.execute("SELECT ISNULL(MAX(InvoiceNumber), 1000) + 1 AS NextNum FROM PurchaseInvoices")
        invoice_number = int(cursor.fetchone()[0])

        cursor.execute(
            """INSERT INTO PurchaseInvoices
               (InvoiceNumber, PersonRef, ShamsiDate, TotalAmount, DiscountAmount,
                TaxAmount, PayableAmount, Description, UserRef)
               VALUES (?,?,?,?,?,?,?,?,?)""",
            (invoice_number, supplier_id, shamsi_date, total_amount, discount_amount or 0,
             tax_amount or 0, payable, description or "", user_id)
        )
        cursor.execute("SELECT @@IDENTITY AS id")
        invoice_id = int(cursor.fetchone()[0])

        for item in items:
            product_id = int(item["product_id"])
            qty = float(item["quantity"])
            price = float(item["unit_price"])
            disc = float(item.get("discount", 0) or 0)
            total_price = qty * price - disc

            cursor.execute(
                """INSERT INTO PurchaseInvoiceItems
                   (InvoiceRef, ProductRef, Quantity, UnitPrice, DiscountAmount, TotalPrice, Description)
                   VALUES (?,?,?,?,?,?,?)""",
                (invoice_id, product_id, qty, price, disc, total_price, item.get("description", ""))
            )
            cursor.execute("SELECT @@IDENTITY AS id")
            item_id = int(cursor.fetchone()[0])

            cursor.execute(
                """INSERT INTO ProductPurchaseLayers
                   (ProductRef, InvoiceItemRef, ShamsiDate, OriginalQuantity, RemainingQuantity, UnitPrice)
                   VALUES (?,?,?,?,?,?)""",
                (product_id, item_id, shamsi_date, qty, qty, price)
            )
            cursor.execute("SELECT @@IDENTITY AS id")
            layer_id = int(cursor.fetchone()[0])

            serials = item.get("serials") or []
            for s in serials:
                s = (s or "").strip()
                if not s:
                    raise InventoryError("سریال/IMEI نمی‌تواند خالی باشد.")
                cursor.execute(
                    "SELECT COUNT(*) FROM ProductSerials WHERE SerialNumber=? AND Status=N'InStock'",
                    (s,)
                )
                if cursor.fetchone()[0] > 0:
                    raise InventoryError(f"سریال/IMEI تکراری است (قبلاً در انبار موجود است): {s}")
                cursor.execute(
                    """INSERT INTO ProductSerials (ProductRef, SerialNumber, IMEI, Status, PurchaseLayerRef)
                       VALUES (?,?,?,N'InStock',?)""",
                    (product_id, s, s, layer_id)
                )

            cursor.execute(
                "UPDATE Products SET CurrentStock = CurrentStock + ?, PurchasePrice = ?, UpdatedAt = GETDATE() WHERE ID = ?",
                (qty, price, product_id)
            )
            cursor.execute("SELECT CurrentStock FROM Products WHERE ID = ?", (product_id,))
            balance = cursor.fetchone()[0]

            cursor.execute(
                """INSERT INTO ProductCardex
                   (ProductRef, ShamsiDate, MovementType, RefTable, RefID,
                    InQuantity, OutQuantity, UnitPrice, BalanceQuantity, Description, UserRef)
                   VALUES (?,?,N'Buy',N'PurchaseInvoices',?,?,0,?,?,?,?)""",
                (product_id, shamsi_date, invoice_id, qty, price, balance,
                 f"فاکتور خرید شماره {invoice_number}", user_id)
            )

        conn.commit()
        return invoice_id, invoice_number

    except Exception:
        conn.rollback()
        raise
    finally:
        cursor.close()
        db.close()
