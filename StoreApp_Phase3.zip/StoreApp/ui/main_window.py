# -*- coding: utf-8 -*-
"""پنجره اصلی (داشبورد) نرم‌افزار"""

from PyQt6.QtWidgets import (
    QMainWindow, QWidget, QVBoxLayout, QHBoxLayout, QLabel,
    QPushButton, QGridLayout, QFrame
)
from PyQt6.QtCore import Qt
import sys, os

sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from utils.persian_date import today_shamsi_str
from ui.persons_window import PersonsWindow
from ui.products_window import ProductsWindow
from ui.purchase_window import PurchaseInvoicesWindow
from ui.sales_window import SalesInvoicesWindow
from services.inventory_service import get_low_stock_products


class MainWindow(QMainWindow):
    def __init__(self, current_user):
        super().__init__()
        self.current_user = current_user
        self.setWindowTitle("نرم‌افزار حسابداری فروشگاه موبایل، لپ‌تاپ و کنسول بازی")
        self.setLayoutDirection(Qt.LayoutDirection.RightToLeft)
        self.resize(950, 620)
        self._build_ui()

    def _build_ui(self):
        central = QWidget()
        main_layout = QVBoxLayout()
        main_layout.setContentsMargins(20, 20, 20, 20)
        main_layout.setSpacing(16)

        # نوار بالا: خوش‌آمد + تاریخ
        top_bar = QHBoxLayout()
        welcome = QLabel(f"خوش آمدید، {self.current_user['FullName']}")
        welcome.setStyleSheet("font-size: 15px; font-weight: bold;")
        date_label = QLabel(f"تاریخ امروز: {today_shamsi_str()}")
        top_bar.addWidget(welcome)
        top_bar.addStretch()
        top_bar.addWidget(date_label)
        main_layout.addLayout(top_bar)

        # هشدار نقطه سفارش (در صورت وجود کالای کمتر از حد مجاز)
        self.low_stock_label = QLabel("")
        self.low_stock_label.setStyleSheet(
            "color: #b30000; font-weight: bold; background-color: #ffe8e8; padding: 8px; border-radius: 4px;"
        )
        self.low_stock_label.setVisible(False)
        main_layout.addWidget(self.low_stock_label)
        self.refresh_low_stock_warning()

        line = QFrame()
        line.setFrameShape(QFrame.Shape.HLine)
        main_layout.addWidget(line)

        # شبکه دکمه‌های ماژول‌ها (مراحل بعدی تکمیل می‌شوند)
        grid = QGridLayout()
        grid.setSpacing(14)

        modules = [
            ("👤 اشخاص", self.open_persons),
            ("📦 کالاها", self.open_products),
            ("🛒 خرید", self.open_purchases),
            ("💰 فروش", self.open_sales),
            ("↩️ برگشت از فروش", self.not_ready),
            ("📄 پیش‌فاکتور", self.not_ready),
            ("⬇️ دریافت", self.not_ready),
            ("⬆️ پرداخت", self.not_ready),
            ("📑 چک‌ها", self.not_ready),
            ("📅 اقساط", self.not_ready),
            ("📊 گزارش‌ها", self.not_ready),
            ("⚙️ تنظیمات", self.not_ready),
        ]

        row, col = 0, 0
        for text, handler in modules:
            btn = QPushButton(text)
            btn.setFixedSize(180, 80)
            btn.setStyleSheet("font-size: 13px;")
            btn.clicked.connect(handler)
            grid.addWidget(btn, row, col)
            col += 1
            if col > 3:
                col = 0
                row += 1

        main_layout.addLayout(grid)
        main_layout.addStretch()

        central.setLayout(main_layout)
        self.setCentralWidget(central)

    def refresh_low_stock_warning(self):
        try:
            low_stock = get_low_stock_products()
        except Exception:
            low_stock = []
        if low_stock:
            names = "، ".join(p["Name"] for p in low_stock[:5])
            more = f" و {len(low_stock) - 5} کالای دیگر" if len(low_stock) > 5 else ""
            self.low_stock_label.setText(f"⚠️ نقطه سفارش: {names}{more} به موجودی هشدار رسیده‌اند.")
            self.low_stock_label.setVisible(True)
        else:
            self.low_stock_label.setVisible(False)

    def open_persons(self):
        self.persons_win = PersonsWindow()
        self.persons_win.show()

    def open_products(self):
        self.products_win = ProductsWindow()
        self.products_win.show()

    def open_purchases(self):
        self.purchases_win = PurchaseInvoicesWindow(self.current_user)
        self.purchases_win.show()

    def open_sales(self):
        self.sales_win = SalesInvoicesWindow(self.current_user)
        self.sales_win.show()

    def not_ready(self):
        from PyQt6.QtWidgets import QMessageBox
        QMessageBox.information(self, "به زودی",
                                 "این بخش در مراحل بعدی ساخته می‌شود.")
