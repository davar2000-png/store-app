# -*- coding: utf-8 -*-
"""
پشتیبان‌گیری و بازیابی کامل دیتابیس نرم‌افزار (StoreAppDB)
از دستورات بومی SQL Server (BACKUP DATABASE / RESTORE DATABASE) استفاده می‌شود
که سریع، قابل اعتماد، و بدون نیاز به کتابخانه اضافه است.
"""

import sys
import os
import pyodbc

sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from config import get_connection_string, SQL_DATABASE


class BackupError(Exception):
    pass


def _get_master_connection():
    """برای Backup/Restore باید به دیتابیس master وصل شویم، نه StoreAppDB"""
    conn_str = get_connection_string("master")
    return pyodbc.connect(conn_str, autocommit=True)


def create_backup(file_path: str):
    """
    یک نسخه پشتیبان کامل از StoreAppDB در مسیر مشخص‌شده می‌سازد.
    نکته: مسیر باید روی همان کامپیوتری باشد که SQL Server رویش نصب است
    (نه لزوما همان مسیری که برنامه از آن اجرا می‌شود، اگر SQL Server روی
    سرور دیگری باشد؛ برای نصب معمولی روی یک سیستم، تفاوتی ندارد).
    """
    try:
        conn = _get_master_connection()
        cursor = conn.cursor()
        query = f"""
            BACKUP DATABASE [{SQL_DATABASE}]
            TO DISK = ?
            WITH FORMAT, INIT, NAME = 'StoreAppDB-Full-Backup';
        """
        cursor.execute(query, (file_path,))
        cursor.close()
        conn.close()
        return True
    except Exception as e:
        raise BackupError(f"خطا در تهیه نسخه پشتیبان: {e}")


def restore_backup(file_path: str):
    """
    دیتابیس StoreAppDB را از فایل پشتیبان مشخص‌شده بازیابی می‌کند.
    تمام اطلاعات فعلی با اطلاعات داخل بک‌آپ جایگزین می‌شود (WITH REPLACE).
    قبل از Restore، همه اتصالات فعال به دیتابیس بسته می‌شوند (SINGLE_USER).
    """
    try:
        conn = _get_master_connection()
        cursor = conn.cursor()

        # قطع تمام اتصالات دیگر به دیتابیس تا Restore با خطا مواجه نشود
        cursor.execute(f"""
            ALTER DATABASE [{SQL_DATABASE}]
            SET SINGLE_USER WITH ROLLBACK IMMEDIATE;
        """)

        cursor.execute(f"""
            RESTORE DATABASE [{SQL_DATABASE}]
            FROM DISK = ?
            WITH REPLACE;
        """, (file_path,))

        cursor.execute(f"""
            ALTER DATABASE [{SQL_DATABASE}]
            SET MULTI_USER;
        """)

        cursor.close()
        conn.close()
        return True
    except Exception as e:
        # تلاش برای بازگرداندن دیتابیس به حالت چند-کاربره در صورت خطا
        try:
            conn2 = _get_master_connection()
            cursor2 = conn2.cursor()
            cursor2.execute(f"ALTER DATABASE [{SQL_DATABASE}] SET MULTI_USER;")
            cursor2.close()
            conn2.close()
        except Exception:
            pass
        raise BackupError(f"خطا در بازیابی نسخه پشتیبان: {e}")


def verify_backup_file(file_path: str) -> dict:
    """بررسی می‌کند فایل بک‌آپ معتبر است و متعلق به کدام دیتابیس بوده (پیش از Restore)"""
    try:
        conn = _get_master_connection()
        cursor = conn.cursor()
        cursor.execute("RESTORE HEADERONLY FROM DISK = ?", (file_path,))
        columns = [c[0] for c in cursor.description]
        row = cursor.fetchone()
        cursor.close()
        conn.close()
        if not row:
            raise BackupError("فایل بک‌آپ معتبر نیست یا خالی است.")
        data = dict(zip(columns, row))
        return {
            "database_name": data.get("DatabaseName"),
            "backup_date": data.get("BackupStartDate"),
        }
    except pyodbc.Error as e:
        raise BackupError(f"فایل بک‌آپ خوانده نشد: {e}")
