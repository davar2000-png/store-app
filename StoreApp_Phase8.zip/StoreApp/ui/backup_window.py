# -*- coding: utf-8 -*-
"""پنجره پشتیبان‌گیری و بازیابی اطلاعات"""

from PyQt6.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QLabel, QPushButton,
    QFileDialog, QMessageBox, QLineEdit
)
from PyQt6.QtCore import Qt
import sys, os
from datetime import datetime

sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from services.backup_service import create_backup, restore_backup, verify_backup_file, BackupError
from utils.persian_date import today_shamsi_str


class BackupWindow(QWidget):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("پشتیبان‌گیری و بازیابی اطلاعات")
        self.setLayoutDirection(Qt.LayoutDirection.RightToLeft)
        self.resize(600, 350)
        self._build_ui()

    def _build_ui(self):
        layout = QVBoxLayout()
        layout.setContentsMargins(30, 30, 30, 30)
        layout.setSpacing(20)

        # بخش تهیه نسخه پشتیبان
        backup_box = QVBoxLayout()
        backup_title = QLabel("💾 تهیه نسخه پشتیبان")
        backup_title.setStyleSheet("font-size: 15px; font-weight: bold;")
        backup_box.addWidget(backup_title)
        backup_desc = QLabel(
            "یک فایل کامل از تمام اطلاعات دیتابیس (اشخاص، کالا، فاکتورها، چک‌ها، اقساط و ...) می‌سازد.\n"
            "توصیه می‌شود این کار را هفته‌ای حداقل یک‌بار انجام دهید."
        )
        backup_desc.setWordWrap(True)
        backup_box.addWidget(backup_desc)

        backup_btn = QPushButton("📥 تهیه نسخه پشتیبان جدید")
        backup_btn.setFixedHeight(42)
        backup_btn.clicked.connect(self.do_backup)
        backup_box.addWidget(backup_btn)
        layout.addLayout(backup_box)

        # خط جداکننده
        sep = QLabel("─" * 60)
        sep.setStyleSheet("color: #ccc;")
        layout.addWidget(sep)

        # بخش بازیابی
        restore_box = QVBoxLayout()
        restore_title = QLabel("♻️ بازیابی نسخه پشتیبان")
        restore_title.setStyleSheet("font-size: 15px; font-weight: bold;")
        restore_box.addWidget(restore_title)
        restore_desc = QLabel(
            "⚠️ هشدار: با انجام این کار، تمام اطلاعات فعلی نرم‌افزار با اطلاعات\n"
            "داخل فایل پشتیبان جایگزین می‌شود و قابل بازگشت نیست."
        )
        restore_desc.setWordWrap(True)
        restore_desc.setStyleSheet("color: #b33;")
        restore_box.addWidget(restore_desc)

        restore_btn = QPushButton("📤 انتخاب فایل و بازیابی")
        restore_btn.setFixedHeight(42)
        restore_btn.clicked.connect(self.do_restore)
        restore_box.addWidget(restore_btn)
        layout.addLayout(restore_box)

        layout.addStretch()
        self.setLayout(layout)

    def do_backup(self):
        default_name = f"StoreAppDB_Backup_{today_shamsi_str().replace('/', '-')}.bak"
        file_path, _ = QFileDialog.getSaveFileName(
            self, "ذخیره نسخه پشتیبان", default_name, "SQL Server Backup (*.bak)"
        )
        if not file_path:
            return

        try:
            create_backup(file_path)
            QMessageBox.information(
                self, "موفق",
                f"نسخه پشتیبان با موفقیت در مسیر زیر ذخیره شد:\n{file_path}"
            )
        except BackupError as e:
            QMessageBox.critical(self, "خطا", str(e))

    def do_restore(self):
        file_path, _ = QFileDialog.getOpenFileName(
            self, "انتخاب فایل پشتیبان", "", "SQL Server Backup (*.bak)"
        )
        if not file_path:
            return

        try:
            info = verify_backup_file(file_path)
        except BackupError as e:
            QMessageBox.critical(self, "خطا", str(e))
            return

        confirm = QMessageBox.warning(
            self, "تأیید نهایی",
            f"این فایل متعلق به دیتابیس «{info['database_name']}» است "
            f"(تاریخ تهیه: {info['backup_date']}).\n\n"
            "با ادامه، تمام اطلاعات فعلی نرم‌افزار پاک و با این فایل جایگزین می‌شود.\n"
            "آیا مطمئن هستید؟",
            QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No
        )
        if confirm != QMessageBox.StandardButton.Yes:
            return

        try:
            restore_backup(file_path)
            QMessageBox.information(
                self, "موفق",
                "بازیابی با موفقیت انجام شد.\nبرنامه را ببندید و دوباره باز کنید."
            )
        except BackupError as e:
            QMessageBox.critical(self, "خطا", str(e))
