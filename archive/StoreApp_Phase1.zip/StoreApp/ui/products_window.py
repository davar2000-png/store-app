# -*- coding: utf-8 -*-
"""مدیریت کالاها: نمایش لیست، افزودن، ویرایش"""

from PyQt6.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QTableWidget, QTableWidgetItem,
    QPushButton, QLineEdit, QDialog, QFormLayout, QCheckBox,
    QMessageBox, QHeaderView, QDoubleSpinBox
)
from PyQt6.QtCore import Qt
import sys, os

sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from database.db import Database


class ProductDialog(QDialog):
    def __init__(self, product=None):
        super().__init__()
        self.product = product
        self.setWindowTitle("ویرایش کالا" if product else "افزودن کالای جدید")
        self.setLayoutDirection(Qt.LayoutDirection.RightToLeft)
        self.setFixedWidth(420)
        self._build_ui()

    def _build_ui(self):
        layout = QFormLayout()

        self.name_input = QLineEdit()
        self.code_input = QLineEdit()
        self.brand_input = QLineEdit()
        self.model_input = QLineEdit()
        self.purchase_price = QDoubleSpinBox()
        self.purchase_price.setMaximum(999999999)
        self.purchase_price.setGroupSeparatorShown(True)
        self.sale_price = QDoubleSpinBox()
        self.sale_price.setMaximum(999999999)
        self.sale_price.setGroupSeparatorShown(True)
        self.has_serial = QCheckBox("کالای سریالی است (موبایل/لپ‌تاپ/کنسول)")

        if self.product:
            self.name_input.setText(self.product.get("Name") or "")
            self.code_input.setText(self.product.get("Code") or "")
            self.brand_input.setText(self.product.get("Brand") or "")
            self.model_input.setText(self.product.get("Model") or "")
            self.purchase_price.setValue(float(self.product.get("PurchasePrice") or 0))
            self.sale_price.setValue(float(self.product.get("SalePrice") or 0))
            self.has_serial.setChecked(bool(self.product.get("HasSerial")))

        layout.addRow("نام کالا:", self.name_input)
        layout.addRow("کد کالا:", self.code_input)
        layout.addRow("برند:", self.brand_input)
        layout.addRow("مدل:", self.model_input)
        layout.addRow("قیمت خرید:", self.purchase_price)
        layout.addRow("قیمت فروش:", self.sale_price)
        layout.addRow(self.has_serial)

        btn_row = QHBoxLayout()
        save_btn = QPushButton("ذخیره")
        save_btn.clicked.connect(self.save)
        cancel_btn = QPushButton("انصراف")
        cancel_btn.clicked.connect(self.reject)
        btn_row.addWidget(save_btn)
        btn_row.addWidget(cancel_btn)
        layout.addRow(btn_row)

        self.setLayout(layout)

    def save(self):
        if not self.name_input.text().strip():
            QMessageBox.warning(self, "خطا", "نام کالا نمی‌تواند خالی باشد.")
            return

        db = Database()
        try:
            if self.product:
                db.execute(
                    """UPDATE Products SET Name=?, Code=?, Brand=?, Model=?,
                       PurchasePrice=?, SalePrice=?, HasSerial=?, UpdatedAt=GETDATE()
                       WHERE ID=?""",
                    (self.name_input.text().strip(), self.code_input.text().strip(),
                     self.brand_input.text().strip(), self.model_input.text().strip(),
                     self.purchase_price.value(), self.sale_price.value(),
                     int(self.has_serial.isChecked()), self.product["ID"])
                )
            else:
                db.execute(
                    """INSERT INTO Products
                       (Name, Code, Brand, Model, PurchasePrice, SalePrice, HasSerial)
                       VALUES (?, ?, ?, ?, ?, ?, ?)""",
                    (self.name_input.text().strip(), self.code_input.text().strip(),
                     self.brand_input.text().strip(), self.model_input.text().strip(),
                     self.purchase_price.value(), self.sale_price.value(),
                     int(self.has_serial.isChecked()))
                )
            db.close()
            self.accept()
        except Exception as e:
            QMessageBox.critical(self, "خطا", f"ذخیره‌سازی ناموفق بود:\n{e}")


class ProductsWindow(QWidget):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("مدیریت کالاها")
        self.setLayoutDirection(Qt.LayoutDirection.RightToLeft)
        self.resize(850, 500)
        self._build_ui()
        self.load_data()

    def _build_ui(self):
        layout = QVBoxLayout()

        top_row = QHBoxLayout()
        self.search_input = QLineEdit()
        self.search_input.setPlaceholderText("جستجو بر اساس نام، کد یا برند...")
        self.search_input.textChanged.connect(self.load_data)
        add_btn = QPushButton("➕ افزودن کالا")
        add_btn.clicked.connect(self.add_product)
        top_row.addWidget(self.search_input)
        top_row.addWidget(add_btn)
        layout.addLayout(top_row)

        self.table = QTableWidget()
        self.table.setColumnCount(7)
        self.table.setHorizontalHeaderLabels(
            ["نام کالا", "کد", "برند", "مدل", "قیمت خرید", "قیمت فروش", ""]
        )
        self.table.horizontalHeader().setSectionResizeMode(0, QHeaderView.ResizeMode.Stretch)
        self.table.setEditTriggers(QTableWidget.EditTrigger.NoEditTriggers)
        layout.addWidget(self.table)

        self.setLayout(layout)

    def load_data(self):
        db = Database()
        search = f"%{self.search_input.text().strip()}%"
        rows = db.fetch_all(
            """SELECT * FROM Products
               WHERE IsDeleted = 0 AND
                     (Name LIKE ? OR Code LIKE ? OR Brand LIKE ?)
               ORDER BY Name""",
            (search, search, search)
        )
        db.close()

        self.table.setRowCount(len(rows))
        for i, r in enumerate(rows):
            self.table.setItem(i, 0, QTableWidgetItem(r["Name"] or ""))
            self.table.setItem(i, 1, QTableWidgetItem(r["Code"] or ""))
            self.table.setItem(i, 2, QTableWidgetItem(r["Brand"] or ""))
            self.table.setItem(i, 3, QTableWidgetItem(r["Model"] or ""))
            self.table.setItem(i, 4, QTableWidgetItem(f"{r['PurchasePrice']:,.0f}"))
            self.table.setItem(i, 5, QTableWidgetItem(f"{r['SalePrice']:,.0f}"))

            edit_btn = QPushButton("ویرایش")
            edit_btn.clicked.connect(lambda checked, row=r: self.edit_product(row))
            self.table.setCellWidget(i, 6, edit_btn)

    def add_product(self):
        dlg = ProductDialog()
        if dlg.exec():
            self.load_data()

    def edit_product(self, product):
        dlg = ProductDialog(product)
        if dlg.exec():
            self.load_data()
