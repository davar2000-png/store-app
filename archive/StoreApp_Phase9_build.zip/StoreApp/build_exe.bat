@echo off
echo ========================================
echo   Building StoreApp executable
echo ========================================
echo.

python --version >nul 2>&1
if errorlevel 1 (
    echo [ERROR] Python is not installed.
    echo Please install Python 3.11 or higher from python.org
    echo During installation, check "Add python.exe to PATH"
    pause
    exit /b 1
)

echo [1/5] Creating virtual environment...
python -m venv venv
call venv\Scripts\activate.bat

echo [2/5] Upgrading pip...
python -m pip install --upgrade pip

echo [3/5] Installing app requirements (this may take a few minutes)...
pip install -r requirements.txt
if errorlevel 1 (
    echo.
    echo [ERROR] Failed to install requirements. See the messages above.
    echo Common causes: no internet connection, or antivirus blocking pip.
    pause
    exit /b 1
)

echo [3.5/5] Verifying PyQt6 installed correctly...
python -c "import PyQt6" 2>nul
if errorlevel 1 (
    echo.
    echo [ERROR] PyQt6 did not install correctly.
    echo Try running this command manually to see the real error:
    echo   venv\Scripts\pip install PyQt6==6.7.1
    pause
    exit /b 1
)

echo [4/5] Installing PyInstaller...
pip install pyinstaller
if errorlevel 1 (
    echo [ERROR] Failed to install PyInstaller.
    pause
    exit /b 1
)

echo [5/5] Building exe file...
pyinstaller --clean StoreApp.spec

echo.
if exist dist\StoreApp.exe (
    echo ========================================
    echo  SUCCESS - Build completed
    echo  Executable file: dist\StoreApp.exe
    echo ========================================
) else (
    echo Build FAILED. Check the messages above.
)
pause
